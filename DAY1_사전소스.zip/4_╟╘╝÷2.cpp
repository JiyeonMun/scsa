﻿#include <cstdio>
// 4_함수2 

int square(int a)
{
	return a * a;
}
int main()
{
	square(3);
	square(3.4);
}
