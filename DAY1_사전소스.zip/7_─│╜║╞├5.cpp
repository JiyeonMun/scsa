﻿int main()
{
	const int c = 10;

	// c의 주소를 double* 에 담고 싶습니다.
	double* p = &c; // ?

}





