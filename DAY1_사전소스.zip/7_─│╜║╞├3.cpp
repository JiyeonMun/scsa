﻿#include <iostream>

// reinterpret_cast 

int main()
{
	double d = 3.4;
	int    n =  d; 

	
}

