// 26 page
#include <iostream>

int main()
{
	char s1[] = "abcd";
	char s2[] = "efgh";

	s1 = s2;

	if (s1 == s2) {}
}