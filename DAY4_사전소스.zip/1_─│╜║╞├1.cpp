﻿#include <iostream>
#include <cstdlib>

int main()
{
	int* p1 = (int*)malloc(sizeof(int) * 10);


}





