﻿#include <iostream>

// 2. reinterpret_cast
//	  서로 다른 타입의 주소 변환
int main()
{
	int n = 0;

	char* p1 = static_cast<char>(&n);
}





