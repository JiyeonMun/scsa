﻿#include <iostream>

// 1. static_cast

int main()
{
	int* p = malloc(sizeof(int) * 10);
}