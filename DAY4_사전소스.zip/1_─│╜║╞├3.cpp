﻿#include <iostream>

// C 스타일 캐스팅의 문제점 
int main()
{
	const int c = 10;

	int* p = &c;

}

