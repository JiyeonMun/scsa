﻿#include <iostream>

// C 스타일 캐스팅의 문제점 
int main()
{
	int n = 0;

	double* p1 = &n;
}

